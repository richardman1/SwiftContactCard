//
//  RestApiManager.swift
//  sep1
//
//  Created by Richard de Jongh on 22/09/16.
//  Copyright © 2016 Richard de Jongh. All rights reserved.
//

import UIKit

class RestApiManager: NSObject {
    
    // Make it singleton
    static let sharedInstance = RestApiManager()
    
    var baseUrl : String?
    var apiKey: String?
    
    override init() {
        baseUrl = "https://randomuser.me/api/"
    }
    
    func getRestPerson(onCompletion: @escaping (NSDictionary?, NSError?) -> Void ) {
        
        // format url van String
        let url = NSURL(string: baseUrl!)!
        
        let request = NSMutableURLRequest(url: url as URL)
        
        // Get
        request.httpMethod = "GET"
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            print("Task done")
            
            if(error != nil) {
                print(error!.localizedDescription)
                onCompletion(nil, error as NSError?)
            }
            
            // Do try .. get json results
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                // succes
                onCompletion(json,nil)
            } catch {
                // failure
                onCompletion(nil,error as NSError)
            }
        })
        task.resume()
    }

    
    
    
    
}
