//
//  ViewController.swift
//  sep1
//
//  Created by Richard de Jongh on 01/09/16.
//  Copyright © 2016 Richard de Jongh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Avatar: UIImageView!
    
    var person : Person?
    
    @IBOutlet weak var firstName: UILabel!
    
    
     override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Avatar.layer.borderColor = UIColor.black.cgColor
        Avatar.layer.borderWidth = 5.0
        Avatar.layer.cornerRadius = 75.0
        Avatar.clipsToBounds = true
        firstName.text = person?.firstName
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

